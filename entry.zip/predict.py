import argparse
from pathlib import Path
from slot_forecasting.baseline import FrequencyForecaster
from slot_forecasting.io import load_inputs, write_submission
p=argparse.ArgumentParser(); p.add_argument('--data'); p.add_argument('--out'); a=p.parse_args()
m=FrequencyForecaster.load(Path(__file__).parent/'baseline.json')
q,h=load_inputs(Path(a.data)/'test')
write_submission(a.out,m.predict(q,h))
